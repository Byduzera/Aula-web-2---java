package br.edu.ifspcjo.ads.web2.adocao.model;

public enum ActivityType {

	CACHORRO("Cachorro"),
	GATO("Gato"),
	OUTROS("Outros");
	
	
	private String type;
	
	ActivityType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

}
