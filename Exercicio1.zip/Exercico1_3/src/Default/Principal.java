package Default;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        ArrayList<Tarefas> listaDeTarefas = new ArrayList<>();
        int opcao;

        do {
            System.out.println("\n--- Menu de Tarefas ---");
            System.out.println("1. Adicionar tarefa");
            System.out.println("2. Remover tarefa");
            System.out.println("3. Listar todas as tarefas");
            System.out.println("4. Sair do programa");
            System.out.print("Escolha uma opção: ");

   
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        adicionarTarefa(scanner, listaDeTarefas);
                        break;
                    case 2:
                        removerTarefa(scanner, listaDeTarefas);
                        break;
                    case 3:
                        listarTarefas(listaDeTarefas);
                        break;
                    case 4:
                        System.out.println("Saindo do programa. Até mais!");
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (Exception e) {
                System.out.println("Entrada inválida. Digite um número de 1 a 4.");
                scanner.nextLine(); 
                opcao = 0; 
            }

        } while (opcao != 4);

        scanner.close();
    }

    
    private static void adicionarTarefa(Scanner scanner, ArrayList<Tarefas> lista) {
        System.out.print("Digite o código da tarefa: ");
        String codigo = scanner.nextLine();
        System.out.print("Digite o título da tarefa: ");
        String titulo = scanner.nextLine();
        
        try {
            Tarefas novaTarefa = new Tarefas(codigo, titulo);
            lista.add(novaTarefa);
            System.out.println("Tarefa adicionada com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro ao adicionar tarefa: " + e.getMessage());
        }
    }

    private static void removerTarefa(Scanner scanner, ArrayList<Tarefas> lista) {
        if (lista.isEmpty()) {
            System.out.println("Não há tarefas para remover.");
            return;
        }

        System.out.print("Digite o código da tarefa que deseja remover: ");
        String codigoParaRemover = scanner.nextLine();
        
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getCodigo().equals(codigoParaRemover)) {
                lista.remove(i);
                System.out.println("Tarefa removida com sucesso!");
                return;
            }
        }
        System.out.println("Tarefa com o código '" + codigoParaRemover + "' não encontrada.");
    }

    private static void listarTarefas(ArrayList<Tarefas> lista) {
        if (lista.isEmpty()) {
            System.out.println("A lista de tarefas está vazia.");
            return;
        }

        System.out.println("\n--- Lista de Tarefas ---");
        
        for (Tarefas t : lista) {
            System.out.println(t); 
        }
    }
}