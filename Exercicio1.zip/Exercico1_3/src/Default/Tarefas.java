package Default;

public class Tarefas {
		private String codigo;
		private String titulo;

		public Tarefas(String codigo2, String titulo2) {
			// TODO Auto-generated constructor stub
		}

		public void Tarefa(String codigo, String titulo) {
			if (codigo == null || codigo.trim().isEmpty() || titulo == null || titulo.trim().isEmpty()) {
				throw new IllegalArgumentException("Código e título da tarefa não podem ser vazios.");
			}
			this.codigo = codigo;
			this.titulo = titulo;
		}

		public String getCodigo() {
			return this.codigo;
		}

		public String getTitulo() {
			return this.titulo;
		}

		public void setCodigo(String novoCodigo) {
			if (novoCodigo != null && !novoCodigo.trim().isEmpty()) {
				this.codigo = novoCodigo;
			} else {
				System.out.println("Erro: O código não pode ser vazio.");
			}
		}

		public void setTitulo(String novoTitulo) {
			if (novoTitulo != null && !novoTitulo.trim().isEmpty()) {
				this.titulo = novoTitulo;
			} else {
				System.out.println("Erro: O título não pode ser vazio.");
			}
		}

		@Override
		public String toString() {
			return "Tarefa [Código: " + codigo + ", Título: " + titulo + "]";
		}
	}
