/**
 * 
 */
/**
 * 
 */
module Execicio1_2 {
	requires java.desktop;
}