package Default;

public class Data {
	private int dia;
	private int mes;
	private int ano;
	
	public Data(int dia, int mes, int ano) {
		setDia(dia);
		setMes(mes);
		setAno(ano);
	}
	
	public void setDia(int novoDia) {
		if (novoDia >= 1 && novoDia <= 30) {
			this.dia = novoDia;
		} else {
			System.out.println("Dia invalido. o numero deve estar entre 1 e 30.");
		}
	}
	
	public void setMes(int novoMes) {
		if (novoMes >= 1 && novoMes <= 12) {
			this.mes = novoMes;
		} else {
			System.out.println("Mes invalido. O mes deve estar entre 1 e 12.");
		}
	}
	
	public void setAno(int novoAno) {
		if (novoAno >= 1900) {
			this.ano = novoAno;
		} else {
			System.out.println("Ano invalido. A ano deve ser acima de 1900.");
		}
	}

	public int getDia() {
		return this.dia;
	}
	
	public int getMes() {
		return this.mes;
	}
	
	public int getAno() {
		return this.ano;
	}
	
	@Override
	public String toString() {
		return String.format("%02d/%02m/%d", dia, mes, ano);
	}
}
