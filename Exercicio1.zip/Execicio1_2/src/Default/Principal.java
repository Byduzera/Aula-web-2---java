package Default;

import javax.swing.JOptionPane;

public class Principal {
	public static void main(String[] args) {
		Data dataAtual = new Data(01, 01, 2025);
		JOptionPane.showMessageDialog(null, "Data inicial: " + dataAtual);
		
	     try {
	           
	            String diaStr = JOptionPane.showInputDialog(null, "Digite o novo dia (1-30):");
	            String mesStr = JOptionPane.showInputDialog(null, "Digite o novo mês (1-12):");
	            String anoStr = JOptionPane.showInputDialog(null, "Digite o novo ano (>= 1900):");

	            int novoDia = Integer.parseInt(diaStr);
	            int novoMes = Integer.parseInt(mesStr);
	            int novoAno = Integer.parseInt(anoStr);

	            dataAtual.setDia(novoDia);
	            dataAtual.setMes(novoMes);
	            dataAtual.setAno(novoAno);
	            
	            JOptionPane.showMessageDialog(null, "Data modificada: " + dataAtual);

	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(null, "Entrada inválida. Certifique-se de digitar apenas números.");
	        }
	    }
	}

