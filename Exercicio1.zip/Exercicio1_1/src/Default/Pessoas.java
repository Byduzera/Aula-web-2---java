package Default;


public class Pessoas {
	String nome;
	int idade;
	
	public Pessoas(String nome, int idade) {
		setNome(nome);
		setIdade(idade);
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome() {
		return nome;
	}
	@Override
	public String toString() {
		return nome + " - " + idade;
	}
	
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getIdade() {
		return idade;
	}
}
