package Default;

public class Principal {

	
	public static void main(String[] args) {
		Pessoas p1 = new Pessoas("Maria", 1);
		System.out.println(p1);
		p1.setNome("Ana");
		p1.setIdade(1);
		System.out.println(p1);
		
	}

}
