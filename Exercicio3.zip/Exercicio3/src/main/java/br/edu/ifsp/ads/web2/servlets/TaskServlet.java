package br.edu.ifsp.ads.web2.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifsp.ads.web2.model.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/tasks")
public class TaskServlet extends HttpServlet {
 
	private static final long serialVersionUID = 1L;
	private List<Task> tasks = new ArrayList<>();
    private int nextId = 1;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String description = request.getParameter("description");
        String dateStr = request.getParameter("date");

        if (description != null && dateStr != null) {
            LocalDate date = LocalDate.parse(dateStr);
            tasks.add(new Task(nextId++, description, date));
            System.out.println(tasks.size());
        }

        request.setAttribute("tasks", tasks);
        request.getRequestDispatcher("/Task-list.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("tasks", tasks);
        request.getRequestDispatcher("/Task-list.jsp").forward(request, response);
    }
}